CVSNT INSTALLATION
===================

Getting Started:
----------------

sudo dpkg -i libssl0.9.8_0.9.8o-7ubuntu3.2.14.04.1_amd64.deb unixodbc_2.2.14p2-5ubuntu5_amd64.deb odbcinst1debian2_2.2.14p2-5ubuntu5_amd64.deb odbcinst_2.2.14p2-5ubuntu5_amd64.deb libodbc1_2.2.14p2-5ubuntu5_amd64.deb cvsnt_2.5.04.3236-1.1_amd64.deb

Note:
-----

Please uninstall existing CVS incase if you face any CVS conflicts and proceed with CVSNT installation

sudo apt-get autoremove cvs
